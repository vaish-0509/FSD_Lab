function Contact({ email, phone }) {
  return (
    <section className="contact">
      <h2>Contact</h2>
      <a className="btn" href={`mailto:${email}`}>Send Email</a>
      <a className="btn btn-outline" href={`tel:${phone.replace(/\s/g, "")}`}>Call Me</a>
    </section>
  );
}

export default Contact;
