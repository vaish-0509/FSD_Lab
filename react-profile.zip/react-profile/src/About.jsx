function About({ about }) {
  return (
    <section className="about">
      <h2>About Me</h2>
      <p>{about}</p>
    </section>
  );
}

export default About;
