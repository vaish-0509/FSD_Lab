import ProfileHeader from "./ProfileHeader";
import ProfileDetails from "./ProfileDetails";
import About from "./About";
import Skills from "./Skills";
import Contact from "./Contact";
import profileData from "./profileData";
import skillsData from "./skillsData";

function Profile() {
  return (
    <div className="profile-card">
      <ProfileHeader profile={profileData} />
      <ProfileDetails profile={profileData} />
      <About about={profileData.about} />
      <Skills skills={skillsData} />
      <Contact email={profileData.email} phone={profileData.phone} />
    </div>
  );
}

export default Profile;
