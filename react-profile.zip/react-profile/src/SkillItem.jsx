function SkillItem({ name, level }) {
  return (
    <li className="skill-item">
      <span className="skill-name">{name}</span>
      <span className={`skill-level ${level.toLowerCase()}`}>{level}</span>
    </li>
  );
}

export default SkillItem;
