import SkillItem from "./SkillItem";

function Skills({ skills }) {
  return (
    <section className="skills">
      <h2>Skills</h2>
      <ul className="skills-list">
        {skills.map((skill) => (
          <SkillItem
            key={skill.id}
            name={skill.name}
            level={skill.level}
          />
        ))}
      </ul>
    </section>
  );
}

export default Skills;
